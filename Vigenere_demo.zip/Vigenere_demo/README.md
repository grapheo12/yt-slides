# Context

This demo was actually given as an assignment in the Cryptography course taken by Prof. Debdeep Mukherjee.

We are given a ciphertext (ciphertext.txt) which is encrypted by Vigenere cipher.
We don't know what the key is but we know that the word `embassystaff` is repeated multiple times.

Read report.pdf to understand the steps.
Then read the docs.pdf to understand the code.


# Running Programs

You can run `make` to get output of all stages together.
We assume that we have the common `bash` environment and that python 3 can be invoked using `python3` command.
Otherwise please change the `PYTHON` variable in the Makefile to your Python path.

## Kasiski test

Run `make stage_1` to get the distances between occurrences of 5, 7 and 12-grams in the ciphertext.

## Index of Coincidence

Run `make stage_2` to get the index of coincidence of all the 17 subsequences of the ciphertext.

## Mutual Index of Coincidence

Run `make stage_3` to see all the 26 keys generated using Mutual Index of Coincidence.

## Key Guessing

Run `make stage_4` to see the 12 character partial key guesses and the partially decrypted plaintext.

## Full key reveal

Run `make stage_5` to see the last 5 letters of the key and the fully decrypted plaintext.

