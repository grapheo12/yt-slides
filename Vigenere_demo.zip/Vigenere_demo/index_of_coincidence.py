def split_strings(text, n):
    strings = []
    for i in range(n):
        strings.append(text[i::n])
        
    return strings


def char_counts(text):
    cnt = [0] * 26
    for s in text:
        cnt[ord(s) - ord('a')] += 1
    return cnt


def index_of_coincidence(text, n):
    strings = split_strings(text, n)
    for s in strings:
        ic = sum([a * a for a in char_counts(s)])
        ic /= (len(s) * len(s))
        print(s, ic)


if __name__ == "__main__":
    text = open("ciphertext.txt", "r").read()[:-1]

    print("\nIndex of Coincidence for key length 17:\n")
    index_of_coincidence(text, 17)