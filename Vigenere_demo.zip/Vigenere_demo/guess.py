def get_key(c, p):
    return "".join(
        [chr((ord(c[i]) - ord(p[i]) + 26) % 26 + ord('a'))
         for i in range(len(c))]
        )


def decrypt(text, key):
    return "".join(
        [chr(((ord(text[i]) - ord('a')) - key[i % len(key)] + 26) % 26 + ord('a'))
         for i in range(len(text))]
        )


if __name__ == "__main__":
    text = open("ciphertext.txt", "r").read()[:-1]
    key1 = get_key("tfiksqwvrjye", "embassystaff")
    key2 = get_key("wtfiksqwvrjy", "embassystaff")
    plain1 = decrypt(text, [ord(a) - ord('a') for a in key1] + ([0] * 5))
    plain2 = decrypt(text, [ord(a) - ord('a') for a in key2] + ([0] * 5))

    print("\n| 12-gram          | Partial Key      |  Contains embassystaff |")
    print("|------------------|------------------|------------------------|")
    print("| tfiksqwvrjye     |", key1, "    |", ("embassystaff" in plain1), "                 |")
    print("| wtfiksqwvrjy     |", key2, "    |", ("embassystaff" in plain2), "                  |")

    for k, p in [(key1, plain1), (key2, plain2)]:
        if "embassystaff" in p:
            print("\nDecrypted text for partial key", k, ":\n")
            print(p)