def get_key(c, p):
    return "".join(
        [chr((ord(c[i]) - ord(p[i]) + 26) % 26 + ord('a'))
         for i in range(len(c))]
        )


def decrypt(text, key):
    return "".join(
        [chr(((ord(text[i]) - ord('a')) - key[i % len(key)] + 26) % 26 + ord('a'))
         for i in range(len(text))]
        )


if __name__ == "__main__":
    text = open("ciphertext.txt", "r").read()[:-1]

    key1 = get_key(text[12: 17], "nleda")
    key2 = get_key(text[17 + 12: 17 + 17], "bleli")

    print("\nFinding last 5 letters of the key:\n")
    print("| Plaintext | Ciphertext | Partial Key |")
    print("|-----------|------------|-------------|")
    print("| nleda     |", text[12: 17], "     |", key1, "      |")
    print("| bleli     |", text[17 + 12: 17 + 17], "     |", key2, "      |")

    key = "sheisasecret" + key1
    print("\nFull key:", key)
    print("\nFully decrypted plaintext:\n")
    plain1 = decrypt(text, [ord(a) - ord('a') for a in key])
    print(plain1)