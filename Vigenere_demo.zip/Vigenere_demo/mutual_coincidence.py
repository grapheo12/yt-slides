def split_strings(text, n):
    strings = []
    for i in range(n):
        strings.append(text[i::n])
        
    return strings


def char_counts(text):
    cnt = [0] * 26
    for s in text:
        cnt[ord(s) - ord('a')] += 1
    return cnt


def shift_string(text, r):
    # Shift forward by r places
    
    return "".join([chr((ord(a) - ord('a') + r) % 26 + ord('a'))
                    for a in text])


def mutual_coincidence(text, n):
    # Calculate index of mutual coincidence
    # of 1st group with remaining (n - 1) groups
    
    strings = split_strings(text, n)
    mic = [0] * 26
    key_diffs = []

    # For each of the 26 shifts of strings[0], find the character counts
    shift_cnts = [char_counts(shift_string(strings[0], i)) for i in range(26)]
    
    for s in strings[1:]:
        for i in range(26):
            cnt1 = char_counts(s)
            cnt2 = shift_cnts[i]
            mic[i] = sum([cnt1[i] * cnt2[i] for i in range(26)])
            mic[i] /= (len(strings[0]) * len(s))
        key_diffs.append(mic.index(max(mic)))
        print(max(mic))
        
    return [0] + key_diffs


def decrypt(text, key):
    return "".join(
        [chr(((ord(text[i]) - ord('a')) - key[i % len(key)] + 26) % 26 + ord('a'))
         for i in range(len(text))]
        )


def min_edit_distance(text, s):
    # Calculate minimum edits required
    # in any same-length substring of text to convert it to s
    ans = float('inf')
    for i in range(len(text) - len(s) + 1):
        cmp_str = text[i: i + len(s)]
        buff = 0
        for j in range(len(s)):
            if cmp_str[j] != s[j]:
                buff += 1
        
        if ans > buff:
            ans = buff
    return ans


if __name__ == "__main__":
    text = open("ciphertext.txt", "r").read()[:-1]

    print("\nMaximum mutual index of coincidence for each letter of the key:\n")
    key_diffs = mutual_coincidence(text, 17)

    print("\nInferred key distances:")
    print(key_diffs)

    min_dist = float('inf')
    best_key = ""

    print("\n")
    print("| Possible key      | Minimum edit distance from embassystaff |")
    print("|-------------------|-----------------------------------------|")
    for i in range(26):
        p = decrypt(text, [(a + i) % 26 for a in key_diffs])
        dist = min_edit_distance(p, "embassystaff")
        if dist < min_dist:
            min_dist = dist
            best_key = ''.join([chr((a + i) % 26 + ord('a')) for a in key_diffs])
        print("|",
              ''.join([chr((a + i) % 26 + ord('a')) for a in key_diffs]),
              "|",
              str(dist).ljust(len("Minimum edit distance from embassystaff")),
              "|"
             )

    print("\nBest Key:", best_key)
    print("\nDecrypted plain text:\n")
    print(decrypt(text, [ord(a) - ord('a') for a in best_key]))
