from collections import defaultdict
from pprint import pprint


def n_gram_statistics(text, n):
    indexes = defaultdict(lambda: [])
    
    i = 0
    while i < len(text) - n + 1:
        chunk = text[i:i + n]
        indexes[chunk].append(i)
        i += 1
        
    return indexes


def inter_distance(indexes):
    # Discards single occurences
    dist = dict()
    for k, v in indexes.items():
        if len(v) > 1:
            dist[k] = [v[i + 1] - v[i] for i in range(len(v) - 1)]
        
    return dist


if __name__ == "__main__":
    text = open("ciphertext.txt", "r").read()[:-1]
    
    for n in [7, 5, 12]:
        print("\nDistances between occurrences of %d-grams:\n" % n)
        idxs = n_gram_statistics(text, n)
        pprint(inter_distance(idxs))